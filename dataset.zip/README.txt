SemEval-2018 Task 1 Affect in Tweets Dataset
Feb 2018
Copyright (C) 2018 National Research Council Canada (NRC)
----------------------------------------------------------------

Dataset: 
-------------------------------------------------
Separate training, development, and test datasets for English tweets were provided. 
The dataset has 4 columns, ID, Tweet, Affect Dimension, and Intensity Classes.
You can drop the Affect Dimension column as it's not useful. You can focus to column Tweet, and Intensity Classes.

Feel free to ask if there is a question related in the dataset


